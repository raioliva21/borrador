#!/usr/bin/env python3

# por planteamiento, esta clase no requiere mayor contenido
# superclase en clases Hierba, Rabano, Trebol y Violeta

class Plant():
    def __init__(self):
        pass