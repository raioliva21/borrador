#!/usr/bin/env python3
from plant import Plant

class Rabano(Plant):
    def __init__(self):
        super().__init__()
        # atributo publico
        self.letra = "R"